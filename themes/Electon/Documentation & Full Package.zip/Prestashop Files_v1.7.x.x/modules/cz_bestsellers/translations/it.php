<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{cz_bestsellers}prestashop>cz_bestsellers_d7b2933ba512ada478c97fa43dd7ebe6'] = ' I migliori venditori';
$_MODULE['<{cz_bestsellers}prestashop>cz_bestsellers_eae99cd6a931f3553123420b16383812'] = 'Tutti i migliori venditori';
