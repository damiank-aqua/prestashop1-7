<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{cz_testimonialcmsblock}prestashop>cz_testimonialcmsblock_5552a9d1c84dc70353b3c2218606c26b'] = 'Cosa dice la gente';
