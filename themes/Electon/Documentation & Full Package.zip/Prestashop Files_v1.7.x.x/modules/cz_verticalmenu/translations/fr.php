<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{cz_verticalmenu}prestashop>cz_verticalmenu_a6a2a55bea8760389dfca77132905b7c'] = 'toutes catégories';
